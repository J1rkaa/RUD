import tkinter as tk
from tkinter import ttk
import webbrowser

class PodilObceGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Výpočet Podílu Obce na Sdílených Daních")

        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=1)
        self.root.columnconfigure(2, weight=1)
        self.root.rowconfigure(5, weight=1)

        # Vytvoření validátoru pro povolení pouze číselného vstupu
        self.validate_command = root.register(self.validate_input)

        self.entry_vymery = ttk.Entry(root, validate="key", validatecommand=(self.validate_command, "%P"))
        self.entry_obcanu = ttk.Entry(root, validate="key", validatecommand=(self.validate_command, "%P"))
        self.entry_skol = ttk.Entry(root, validate="key", validatecommand=(self.validate_command, "%P"))
        self.entry_koeficient = ttk.Entry(root, validate="key", validatecommand=(self.validate_command, "%P"))

        self.entry_vymery.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
        self.entry_obcanu.grid(row=1, column=0, padx=10, pady=10, sticky="ew")
        self.entry_skol.grid(row=2, column=0, padx=10, pady=10, sticky="ew")
        self.entry_koeficient.grid(row=3, column=0, padx=10, pady=10, sticky="ew")

        self.menu = tk.Menu(root)
        self.root.config(menu=self.menu)

        # Vytvoření menu "Informace" a přidání položek
        self.info_menu = tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Informace", menu=self.info_menu)
        self.info_menu.add_command(label="Info", command=self.otevrit_info_okno)

        # Vytvoření menu "Konec" a přidání položky
        self.end_menu = tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Konec", menu=self.end_menu)
        self.end_menu.add_command(label="Ukončit", command=self.ukoncit_program)

        # Výměry
        button_vymery = ttk.Button(root, text="Výměra", command=self.vypocet_vymery)
        button_vymery.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

        # Obyvatelé
        button_obcanu = ttk.Button(root, text="Obyvatelé", command=self.vypocet_obcanu)
        button_obcanu.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

        # Školy
        button_skol = ttk.Button(root, text="Školy", command=self.vypocet_skol)
        button_skol.grid(row=2, column=1, padx=10, pady=10, sticky="ew")

        # Koeficient
        button_koeficient = ttk.Button(root, text="Koeficient", command=self.vypocet_koeficient)
        button_koeficient.grid(row=3, column=1, padx=10, pady=10, sticky="ew")

        button_soucet = ttk.Button(root, text="Provést součet", command=self.provest_soucet)
        button_soucet.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

        self.label_vymery = tk.Label(root, text="", font=("Helvetica", 10, "bold"), wraplength=root.winfo_width())
        self.label_obcanu = tk.Label(root, text="", font=("Helvetica", 10, "bold"), wraplength=root.winfo_width())
        self.label_skol = tk.Label(root, text="", font=("Helvetica", 10, "bold"), wraplength=root.winfo_width())
        self.label_koeficient = tk.Label(root, text="", font=("Helvetica", 10, "bold"), wraplength=root.winfo_width())
        self.label_celkem = tk.Label(root, text="", font=("Helvetica", 16, "bold"), fg="green", wraplength=root.winfo_width())

        self.label_vymery.grid(row=0, column=2, padx=10, pady=10, sticky="w")
        self.label_obcanu.grid(row=1, column=2, padx=10, pady=10, sticky="w")
        self.label_skol.grid(row=2, column=2, padx=10, pady=10, sticky="w")
        self.label_koeficient.grid(row=3, column=2, padx=10, pady=10, sticky="w")
        self.label_celkem.grid(row=5, column=0, columnspan=3, padx=10, pady=10, sticky="ew")

        self.vysledek0 = 0
        self.vysledek1 = 0
        self.vysledek2 = 0
        self.novy_vysledek = 0

        # Propojení kláves Enter s funkcemi pro každé pole
        self.entry_vymery.bind("<Return>", lambda event: self.vypocet_vymery())
        self.entry_obcanu.bind("<Return>", lambda event: self.vypocet_obcanu())
        self.entry_skol.bind("<Return>", lambda event: self.vypocet_skol())
        self.entry_koeficient.bind("<Return>", lambda event: self.vypocet_koeficient())

    def validate_input(self, new_text):
        if new_text == "":
            return True
        try:
            float(new_text)
            return True
        except ValueError:
            return False

    def vypocet_vymery(self):
        try:
            zadana_hodnota = float(self.entry_vymery.get())
            self.vysledek0 = (zadana_hodnota / 7569130.6542) * 0.03 * 100
            if self.vysledek0 != 0:
                self.zobraz_vysledek(self.label_vymery, "✔️", color="green")
            else:
                self.zobraz_vysledek(self.label_vymery, "❌", color="red")
        except ValueError:
            self.zobraz_error("❌Zadejte platnou číselnou hodnotu výměry.")

    def vypocet_obcanu(self):
        try:
            zadana_hodnota = float(self.entry_obcanu.get())
            self.vysledek1 = (zadana_hodnota / 8609358) * 0.10 * 100
            if self.vysledek1 != 0:
                self.zobraz_vysledek(self.label_obcanu, "✔️", color="green")
            else:
                self.zobraz_vysledek(self.label_obcanu, "❌", color="red")
            # Automatické doplnění celočíselné hodnoty do pole pro koeficient
            self.entry_koeficient.delete(0, tk.END)
            self.entry_koeficient.insert(0, str(int(zadana_hodnota)))
            # Automatický výpočet koeficientu
            self.vypocet_koeficient()
        except ValueError:
            self.zobraz_error("❌Zadejte platnou číselnou hodnotu obyvatel.")

    def vypocet_skol(self):
        try:
            zadana_hodnota = float(self.entry_skol.get())
            self.vysledek2 = (zadana_hodnota / 1071167) * 0.09 * 100
            if self.vysledek2 != 0:
                self.zobraz_vysledek(self.label_skol, "✔️", color="green")
            else:
                self.zobraz_vysledek(self.label_skol, "❌", color="red")
        except ValueError:
            self.zobraz_error("❌Zadejte platnou číselnou hodnotu škol.")

    def vypocet_koeficient(self):
        try:
            pocet_obcanu = int(self.entry_koeficient.get())
            if 51 <= pocet_obcanu <= 2000:
                vysledek = 50 + 1.0700 * (pocet_obcanu - 50)
            elif 2001 <= pocet_obcanu <= 30000:
                vysledek = 2136.5 + 1.1523 * (pocet_obcanu - 2000)
            elif 30001 <= pocet_obcanu <= 300000:
                vysledek = 34400.9 + 1.3663 * (pocet_obcanu - 30000)
            elif 0 <= pocet_obcanu <= 50:
                vysledek = 1.0000 * pocet_obcanu
            else:
                self.zobraz_error("❌Zadali jste neplatný počet občanů.")
                return

            self.novy_vysledek = (vysledek / 9714289.9421) * 0.60948330 * 0.78 * 0.79 * 100
            if self.novy_vysledek != 0:
                self.zobraz_vysledek(self.label_koeficient, "✔️", color="green")
            else:
                self.zobraz_vysledek(self.label_koeficient, "❌", color="red")
        except ValueError:
            self.zobraz_error("❌Zadejte platnou celočíselnou hodnotu koeficientu.")

    def provest_soucet(self):
        soucet = self.vysledek0 + self.vysledek1 + self.vysledek2 + self.novy_vysledek
        vysledek_celkem = (soucet / 100) * 288111511594.68
        self.zobraz_vysledek(self.label_celkem, "Celkový výsledek je: {:.2f} Kč".format(vysledek_celkem), bold=True, color="green")

    def otevrit_info_okno(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Informace")
        
        info_text = "Toto je informační okno.\n Jedná se o kalkulačku RUD obcí.\n"
        info_text += "Informace, které potřebujete zjistit k zobrazení rozpočtu, najdete v excelové tabulce vždy pro daný rok.\n"
        info_text += "Pokud chcete modelovat následující rok, použijte poslední zveřejněnou tabulku.\n"
        info_text += "Tyto tabulky naleznete ZDE s názvem Tabulka o procentím podílu obcí.\n Níže vidíte ukázku této tabulky s vyznačenými daty, které potřebujete.\nStačí jen najít svoji obec pomocí klávesové zkratky ctrl+f."
        
        info_label = tk.Label(info_window, text=info_text, wraplength=400)
        info_label.pack()

        # Vytvoření obrázku pod textem
        image_label = tk.Label(info_window)
        image_label.pack()
        # Vložení obrázku
        photo = tk.PhotoImage(file="tabulka.png")  # Změňte cestu k obrázku
        image_label.config(image=photo)
        image_label.image = photo  # Udržení reference na obrázek, aby nebyl smazán Garbage Collectorem

        # Vytvoření odkazu ze slova "ZDE"
        info_text_with_link = info_text.replace("ZDE", "ZDE", 1)
        info_label.config(text=info_text_with_link)
        info_label.bind("<Button-1>", lambda event: self.open_link())

    def open_link(self):
        webbrowser.open("https://www.mfcr.cz/cs/kontrola-a-regulace/legislativa/legislativni-dokumenty")

    def zobraz_vysledek(self, label, message, bold=False, color=None):
        label.config(text=message)
        if bold:
            label.config(font=("Helvetica", 16, "bold"))
        if color:
            label.config(fg=color)
        label.config(wraplength=self.root.winfo_width())

    def zobraz_error(self, message):
        self.label_celkem.config(text="Chyba: " + message, fg="red", wraplength=self.root.winfo_width())

    def ukoncit_program(self):
        self.root.destroy()

# Hlavní program
root = tk.Tk()
app = PodilObceGUI(root)
root.mainloop()
